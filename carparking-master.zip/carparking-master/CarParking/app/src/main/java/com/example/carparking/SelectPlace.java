package com.example.carparking;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SelectPlace extends AppCompatActivity {

    private Spinner citySpinner;
    private Spinner placeSpinner;
    private Map<String, List<String>> placesByCity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_place);

        citySpinner = findViewById(R.id.citySpinner);
        placeSpinner = findViewById(R.id.placeSpinner);

        // Set up city data
        final String[] cities = {"Udupi", "Manipal", "Karkala"};

        // Set up places for each city
        placesByCity = new HashMap<>();
        placesByCity.put("Udupi", List.of("MGM", "Bannanje", "Krishnamata"));
        placesByCity.put("Manipal", List.of("KMC", "KFC", "MIT"));
        placesByCity.put("Karkala", List.of("Miyar", "Bailur", "Bajagoli"));

        // Set up city spinner
        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, cities);
        cityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        citySpinner.setAdapter(cityAdapter);

        // Set up listener for city selection
        citySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCity = cities[position];
                List<String> places = placesByCity.get(selectedCity);
                updatePlaceSpinner(places);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    private void updatePlaceSpinner(List<String> places) {
        ArrayAdapter<String> placeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, places);
        placeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        placeSpinner.setAdapter(placeAdapter);
    }
}
