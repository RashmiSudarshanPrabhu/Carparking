package com.example.carparking;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class bookings extends AppCompatActivity {

    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookings);  // Link to your Bookings layout

        // Find the back button by its ID
        backButton = findViewById(R.id.backButton);

        // Set up the back button to go back to the previous page (slotbooking or user page)
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Use intent to navigate back to the previous activity (UserActivity in this case)
                Intent intent = new Intent(bookings.this, userpage.class); // Change to the previous activity if needed
                startActivity(intent);
                finish(); // Optionally close this activity to prevent returning to it
            }
        });
    }
}
