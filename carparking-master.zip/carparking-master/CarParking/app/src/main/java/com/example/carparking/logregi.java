package com.example.carparking;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class logregi extends AppCompatActivity {
    private EditText phoneNumber, password;
    private Button loginButton;
    private DatabaseHelper databaseHelper; // Database helper instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logregi);

        // Initialize views and database helper
        databaseHelper = new DatabaseHelper(this);

        phoneNumber = findViewById(R.id.phone_number);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);

        loginButton.setOnClickListener(v -> validateForm());
        TextView Signup_link = findViewById(R.id.sign_up_link);
        Signup_link.setOnClickListener(view -> {
            Intent intent = new Intent(logregi.this, signup.class);
            startActivity(intent);
        });
    }

    private void validateForm() {
        String phoneNumberInput = phoneNumber.getText().toString().trim();
        String passwordInput = password.getText().toString().trim();

        if (TextUtils.isEmpty(phoneNumberInput)) {
            phoneNumber.setError("Phone Number is required");
            return;
        }

        if (TextUtils.isEmpty(passwordInput)) {
            password.setError("Password is required");
            return;
        }

        // Check user credentials
        boolean isValidUser = databaseHelper.checkUser(phoneNumberInput, passwordInput);
        if (isValidUser) {
            Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show();
            // Proceed to the next activity (e.g., user dashboard)
            Intent intent = new Intent(logregi.this, userpage.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Invalid Phone Number or Password", Toast.LENGTH_SHORT).show();
        }
    }
}
