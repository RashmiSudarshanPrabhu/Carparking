package com.example.carparking;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class pay extends AppCompatActivity {

    private EditText amountEditText;
    private Spinner paymentModeSpinner;
    private Button confirmButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay);

        // Find views
        amountEditText = findViewById(R.id.amountEditText);
        paymentModeSpinner = findViewById(R.id.paymentModeSpinner);
        confirmButton = findViewById(R.id.confirmButton);

        // Get the amount from the previous activity
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("amount")) {
            int amount = intent.getIntExtra("amount", 0);
            amountEditText.setText(String.valueOf(amount));
        }

        amountEditText.setEnabled(false);  // Disable the amount field as it's only for display

        // Handle confirm button click
        confirmButton.setOnClickListener(v -> {
            // Transaction logic can go here. For now, just a simple toast.
            Toast.makeText(pay.this, "Payment successful!", Toast.LENGTH_SHORT).show();
            // Optionally, go back to slots page or another success page
            Intent successIntent = new Intent(pay.this, slots.class);
            startActivity(successIntent);
        });
    }
}
