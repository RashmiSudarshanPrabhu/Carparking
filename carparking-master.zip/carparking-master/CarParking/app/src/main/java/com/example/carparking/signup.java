package com.example.carparking;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class signup extends AppCompatActivity {
    private EditText username, phoneNumber, carNumber, email, password, confirmPassword;
    private Button signUpButton;
    private DatabaseHelper databaseHelper; // Database helper instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Initialize views and database helper
        databaseHelper = new DatabaseHelper(this);

        username = findViewById(R.id.username);
        phoneNumber = findViewById(R.id.phone_number);
        carNumber = findViewById(R.id.car_number);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirm_password);
        signUpButton = findViewById(R.id.signup_button);

        // Set listener for sign up button
        signUpButton.setOnClickListener(v -> validateForm());

        // Set listener for login link
        TextView login_link = findViewById(R.id.login_link);
        login_link.setOnClickListener(view -> {
            Intent intent = new Intent(signup.this, logregi.class);
            startActivity(intent);
        });
    }

    private void validateForm() {
        String userNameInput = username.getText().toString().trim();
        String phoneNumberInput = phoneNumber.getText().toString().trim();
        String emailInput = email.getText().toString().trim();
        String passwordInput = password.getText().toString().trim();
        String confirmPasswordInput = confirmPassword.getText().toString().trim();

        // Username validation: less than 20 characters, no special characters
        if (TextUtils.isEmpty(userNameInput)) {
            username.setError("User Name is required");
            return;
        } else if (userNameInput.length() > 20) {
            username.setError("User Name should be less than 20 characters");
            return;
        } else if (!userNameInput.matches("[a-zA-Z0-9]+")) {  // Only letters and numbers allowed
            username.setError("User Name should not contain special characters");
            return;
        }

        // Phone number validation: 10 digits only
        if (TextUtils.isEmpty(phoneNumberInput)) {
            phoneNumber.setError("Phone Number is required");
            return;
        } else if (!phoneNumberInput.matches("[0-9]{10}")) {  // Must be exactly 10 digits
            phoneNumber.setError("Phone Number must be 10 digits long");
            return;
        }

        // Email validation: should end with @gmail.com, no numbers allowed
        if (TextUtils.isEmpty(emailInput)) {
            email.setError("Email is required");
            return;
        } else if (!emailInput.endsWith("@gmail.com") || emailInput.matches(".*\\d.*")) { // Must end with @gmail.com and no numbers
            email.setError("Email must be a valid @gmail.com address and should not contain numbers");
            return;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
            email.setError("Invalid Email format");
            return;
        }

        // Password validation: minimum 6 characters, 1 uppercase, 1 lowercase, 1 digit, 1 special character
        if (TextUtils.isEmpty(passwordInput)) {
            password.setError("Password is required");
            return;
        } else if (passwordInput.length() < 6) {
            password.setError("Password should be at least 6 characters long");
            return;
        } else if (!isValidPassword(passwordInput)) {
            password.setError("Password must contain at least 1 uppercase letter, 1 lowercase letter, 1 digit, and 1 special character");
            return;
        }

        // Confirm password check
        if (!passwordInput.equals(confirmPasswordInput)) {
            confirmPassword.setError("Passwords do not match");
            return;
        }

        // Save user to database
        boolean isInserted = databaseHelper.insertUser(userNameInput, phoneNumberInput, passwordInput);
        if (isInserted) {
            Toast.makeText(this, "Sign Up Successful!", Toast.LENGTH_SHORT).show();

            // Redirect to login page after successful registration
            Intent intent = new Intent(signup.this, logregi.class);
            startActivity(intent);
            finish(); // Finish the signup activity so the user can't navigate back to it
        } else {
            Toast.makeText(this, "Sign Up Failed!", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper method to validate password complexity
    private boolean isValidPassword(String password) {
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{6,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);
        return matcher.matches();
    }
}
