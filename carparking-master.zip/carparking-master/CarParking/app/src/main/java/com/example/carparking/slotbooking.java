// Updated slotbooking.java
package com.example.carparking;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class slotbooking extends AppCompatActivity {

    private TextView inTimeTextView, outTimeTextView, amountTextView;
    private Button calculateAmountButton, payButton;
    private Calendar selectedInTimeCalendar, selectedOutTimeCalendar;
    private int calculatedAmount = 0;
    private SharedPreferences sharedPreferences;
    private static final String BOOKED_SLOT_PREFS = "booked_slots";
    private int slotNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slotbooking);

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(BOOKED_SLOT_PREFS, MODE_PRIVATE);

        // Find views by their IDs
        inTimeTextView = findViewById(R.id.inTimeTextView);
        outTimeTextView = findViewById(R.id.outTimeTextView);
        amountTextView = findViewById(R.id.amountTextView);
        calculateAmountButton = findViewById(R.id.calculateAmountButton);
        payButton = findViewById(R.id.payButton);

        // Get slot number from Intent
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("slotNumber")) {
            slotNumber = intent.getIntExtra("slotNumber", -1);
        }

        if (slotNumber == -1 || isSlotBooked(String.valueOf(slotNumber))) {
            Toast.makeText(this, "This slot is already booked!", Toast.LENGTH_SHORT).show();
            payButton.setEnabled(false);  // Disable pay button
            return;
        }

        // Initialize in-time and out-time calendars
        selectedInTimeCalendar = Calendar.getInstance();
        selectedOutTimeCalendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());

        // Set up TimePicker for in-time
        inTimeTextView.setOnClickListener(v -> {
            int hour = selectedInTimeCalendar.get(Calendar.HOUR_OF_DAY);
            int minute = selectedInTimeCalendar.get(Calendar.MINUTE);
            new TimePickerDialog(slotbooking.this, (view, hourOfDay, minute1) -> {
                selectedInTimeCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                selectedInTimeCalendar.set(Calendar.MINUTE, minute1);
                inTimeTextView.setText(dateFormat.format(selectedInTimeCalendar.getTime()));
            }, hour, minute, true).show();
        });

        // Set up TimePicker for out-time
        outTimeTextView.setOnClickListener(v -> {
            int hour = selectedOutTimeCalendar.get(Calendar.HOUR_OF_DAY);
            int minute = selectedOutTimeCalendar.get(Calendar.MINUTE);
            new TimePickerDialog(slotbooking.this, (view, hourOfDay, minute12) -> {
                selectedOutTimeCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                selectedOutTimeCalendar.set(Calendar.MINUTE, minute12);
                outTimeTextView.setText(dateFormat.format(selectedOutTimeCalendar.getTime()));
            }, hour, minute, true).show();
        });

        // Calculate the amount based on the in-time and out-time
        calculateAmountButton.setOnClickListener(v -> {
            long totalMinutes = calculateDifferenceInMinutes(selectedInTimeCalendar.getTime(), selectedOutTimeCalendar.getTime());
            calculatedAmount = calculateAmount(totalMinutes);
            amountTextView.setText("Total Amount: ₹" + calculatedAmount);
        });

        // Set up Pay button to mark the slot as booked and proceed to payment
        payButton.setOnClickListener(v -> {
            markSlotAsBooked(String.valueOf(slotNumber));

            Intent payIntent = new Intent(slotbooking.this, pay.class);
            payIntent.putExtra("amount", calculatedAmount);
            startActivity(payIntent);
        });
    }

    private boolean isSlotBooked(String slotNumber) {
        return sharedPreferences.getBoolean(slotNumber, false);
    }

    private void markSlotAsBooked(String slotNumber) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(slotNumber, true);

        editor.apply();
    }

    private long calculateDifferenceInMinutes(java.util.Date inTime, java.util.Date outTime) {
        long differenceInMillis = outTime.getTime() - inTime.getTime();
        return differenceInMillis / (1000 * 60);
    }

    private int calculateAmount(long totalMinutes) {
        if (totalMinutes <= 60) {
            return 30;  // ₹30 for the first hour
        } else {
            long additionalMinutes = totalMinutes - 60;
            long additionalHours = (long) Math.ceil(additionalMinutes / 60.0);
            return 30 + (int) (additionalHours * 20);  // ₹20 for each additional hour
        }
    }
}
