package com.example.carparking;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class slots extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private static final String BOOKED_SLOT_PREFS = "booked_slots";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slots);  // Linking to your XML layout

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(BOOKED_SLOT_PREFS, MODE_PRIVATE);

        // Find the GridLayout where buttons will be added
        GridLayout gridLayout = findViewById(R.id.gridLayout);

        // Create 10 ImageButtons dynamically with slot numbers
        for (int i = 1; i <= 10; i++) {
            // Create a new LinearLayout to hold the ImageButton and the slot number TextView
            LinearLayout buttonLayout = new LinearLayout(this);
            buttonLayout.setOrientation(LinearLayout.VERTICAL);  // Set orientation to vertical
            buttonLayout.setGravity(Gravity.CENTER);  // Center items within the layout

            // Create the ImageButton
            ImageButton imageButton = new ImageButton(this);
            imageButton.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.car_icon));  // Ensure drawable is correct
            imageButton.setBackgroundResource(android.R.color.transparent);  // Remove the button background
            imageButton.setContentDescription("Slot " + i);
            imageButton.setTag(i);  // Tag to identify the button

            // Check if the slot is booked
            if (isSlotBooked(i)) {
                imageButton.setEnabled(false);  // Disable the button if the slot is booked
                imageButton.setAlpha(0.5f);  // Reduce opacity to visually indicate that it's booked
            }

            // Set click listener for each button
            imageButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int slotNumber = (int) v.getTag();  // Get the tag to identify the button

                    // Start the SlotBookingActivity and pass the slot number as an extra
                    Intent intent = new Intent(slots.this, slotbooking.class);
                    intent.putExtra("slotNumber", slotNumber);
                    startActivity(intent);
                }
            });

            // Create a TextView to display the slot number and make it bold
            TextView slotNumberView = new TextView(this);
            slotNumberView.setText("Slot " + i);
            slotNumberView.setGravity(Gravity.CENTER);
            slotNumberView.setTypeface(null, Typeface.BOLD);  // Make the slot number bold

            // Add the ImageButton and TextView to the LinearLayout
            buttonLayout.addView(imageButton);
            buttonLayout.addView(slotNumberView);

            // Set layout parameters to properly display in grid format with 2 columns
            GridLayout.LayoutParams gridLayoutParams = new GridLayout.LayoutParams();
            gridLayoutParams.setMargins(16, 16, 16, 16);  // Add margin between grid items

            // Add the LinearLayout (with ImageButton and TextView) to the GridLayout
            gridLayout.addView(buttonLayout, gridLayoutParams);
        }
    }

    // Function to check if the slot is already booked
    private boolean isSlotBooked(int slotNumber) {
        return sharedPreferences.getBoolean(String.valueOf(slotNumber), false);
    }
}
