package com.example.carparking; // Replace with your package name

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class userpage extends AppCompatActivity {

    // Define the ImageViews
    private ImageView bookSlotImageView;
    private ImageView myBookingsImageView;
    private ImageView logoutImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userpage); // Replace with your layout name

        // Initialize ImageViews
        bookSlotImageView = findViewById(R.id.book_slot); // Make sure to set the correct IDs
        myBookingsImageView = findViewById(R.id.my_bookings); // Make sure to set the correct IDs
        logoutImageView = findViewById(R.id.logout); // Make sure to set the correct IDs

        // Set click listeners
        bookSlotImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(userpage.this,slots.class);
                startActivity(intent);
            }
        });

        myBookingsImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(userpage.this, bookings.class);
                startActivity(intent);
            }
        });

        logoutImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Logic for logging out (e.g., clear session, etc.)
                Intent intent = new Intent(userpage.this, MainActivity.class);
                startActivity(intent);
                finish(); // Finish this activity if you want to prevent going back to it
            }
        });
    }
}
